<?php
$dalTableaplikasisurveyuggroups = array();
$dalTableaplikasisurveyuggroups["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID", "autoInc" => "1");
$dalTableaplikasisurveyuggroups["Label"] = array("type"=>200,"varname"=>"Label", "name" => "Label", "autoInc" => "0");
$dalTableaplikasisurveyuggroups["Provider"] = array("type"=>200,"varname"=>"Provider", "name" => "Provider", "autoInc" => "0");
$dalTableaplikasisurveyuggroups["Comment"] = array("type"=>201,"varname"=>"Comment", "name" => "Comment", "autoInc" => "0");
$dalTableaplikasisurveyuggroups["GroupID"]["key"]=true;

$dal_info["dataAplikasiSurveyatlocalhost__aplikasisurveyuggroups"] = &$dalTableaplikasisurveyuggroups;
?>