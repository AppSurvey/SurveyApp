<?php
$dalTableAplikasiSurvey = array();
$dalTableAplikasiSurvey["id"] = array("type"=>3,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTableAplikasiSurvey["Nama/Inisal"] = array("type"=>200,"varname"=>"Nama_Inisal", "name" => "Nama/Inisal", "autoInc" => "0");
$dalTableAplikasiSurvey["Umur"] = array("type"=>200,"varname"=>"Umur", "name" => "Umur", "autoInc" => "0");
$dalTableAplikasiSurvey["Tanggal Kunjungan"] = array("type"=>7,"varname"=>"Tanggal_Kunjungan", "name" => "Tanggal Kunjungan", "autoInc" => "0");
$dalTableAplikasiSurvey["Waktu Kunjungan"] = array("type"=>134,"varname"=>"Waktu_Kunjungan", "name" => "Waktu Kunjungan", "autoInc" => "0");
$dalTableAplikasiSurvey["Poli"] = array("type"=>200,"varname"=>"Poli", "name" => "Poli", "autoInc" => "0");
$dalTableAplikasiSurvey["Kritik"] = array("type"=>200,"varname"=>"Kritik", "name" => "Kritik", "autoInc" => "0");
$dalTableAplikasiSurvey["Saran"] = array("type"=>200,"varname"=>"Saran", "name" => "Saran", "autoInc" => "0");
$dalTableAplikasiSurvey["Foto"] = array("type"=>200,"varname"=>"Foto", "name" => "Foto", "autoInc" => "0");
$dalTableAplikasiSurvey["id"]["key"]=true;

$dal_info["dataAplikasiSurveyatlocalhost__AplikasiSurvey"] = &$dalTableAplikasiSurvey;
?>