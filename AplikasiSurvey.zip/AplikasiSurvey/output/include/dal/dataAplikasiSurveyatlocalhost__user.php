<?php
$dalTableuser = array();
$dalTableuser["id"] = array("type"=>3,"varname"=>"id", "name" => "id", "autoInc" => "1");
$dalTableuser["user"] = array("type"=>200,"varname"=>"user", "name" => "user", "autoInc" => "0");
$dalTableuser["pasword"] = array("type"=>200,"varname"=>"pasword", "name" => "pasword", "autoInc" => "0");
$dalTableuser["Level"] = array("type"=>200,"varname"=>"Level", "name" => "Level", "autoInc" => "0");
$dalTableuser["id"]["key"]=true;

$dal_info["dataAplikasiSurveyatlocalhost__user"] = &$dalTableuser;
?>