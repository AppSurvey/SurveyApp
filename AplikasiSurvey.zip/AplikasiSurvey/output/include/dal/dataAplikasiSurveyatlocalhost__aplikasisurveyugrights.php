<?php
$dalTableaplikasisurveyugrights = array();
$dalTableaplikasisurveyugrights["TableName"] = array("type"=>200,"varname"=>"TableName", "name" => "TableName", "autoInc" => "0");
$dalTableaplikasisurveyugrights["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID", "autoInc" => "0");
$dalTableaplikasisurveyugrights["AccessMask"] = array("type"=>200,"varname"=>"AccessMask", "name" => "AccessMask", "autoInc" => "0");
$dalTableaplikasisurveyugrights["Page"] = array("type"=>201,"varname"=>"Page", "name" => "Page", "autoInc" => "0");
$dalTableaplikasisurveyugrights["TableName"]["key"]=true;
$dalTableaplikasisurveyugrights["GroupID"]["key"]=true;

$dal_info["dataAplikasiSurveyatlocalhost__aplikasisurveyugrights"] = &$dalTableaplikasisurveyugrights;
?>