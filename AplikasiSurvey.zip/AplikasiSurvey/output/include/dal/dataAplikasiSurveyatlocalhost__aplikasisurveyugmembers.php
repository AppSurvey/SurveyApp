<?php
$dalTableaplikasisurveyugmembers = array();
$dalTableaplikasisurveyugmembers["UserName"] = array("type"=>200,"varname"=>"UserName", "name" => "UserName", "autoInc" => "0");
$dalTableaplikasisurveyugmembers["GroupID"] = array("type"=>3,"varname"=>"GroupID", "name" => "GroupID", "autoInc" => "0");
$dalTableaplikasisurveyugmembers["Provider"] = array("type"=>200,"varname"=>"Provider", "name" => "Provider", "autoInc" => "0");
$dalTableaplikasisurveyugmembers["UserName"]["key"]=true;
$dalTableaplikasisurveyugmembers["GroupID"]["key"]=true;
$dalTableaplikasisurveyugmembers["Provider"]["key"]=true;

$dal_info["dataAplikasiSurveyatlocalhost__aplikasisurveyugmembers"] = &$dalTableaplikasisurveyugmembers;
?>