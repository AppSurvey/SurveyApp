<?php
$tdataaplikasisurvey = array();
$tdataaplikasisurvey[".searchableFields"] = array();
$tdataaplikasisurvey[".ShortName"] = "aplikasisurvey";
$tdataaplikasisurvey[".OwnerID"] = "";
$tdataaplikasisurvey[".OriginalTable"] = "aplikasisurvey";


$tdataaplikasisurvey[".pagesByType"] = my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" );
$tdataaplikasisurvey[".originalPagesByType"] = $tdataaplikasisurvey[".pagesByType"];
$tdataaplikasisurvey[".pages"] = types2pages( my_json_decode( "{\"add\":[\"add\"],\"edit\":[\"edit\"],\"export\":[\"export\"],\"import\":[\"import\"],\"list\":[\"list\"],\"print\":[\"print\"],\"search\":[\"search\"],\"view\":[\"view\"]}" ) );
$tdataaplikasisurvey[".originalPages"] = $tdataaplikasisurvey[".pages"];
$tdataaplikasisurvey[".defaultPages"] = my_json_decode( "{\"add\":\"add\",\"edit\":\"edit\",\"export\":\"export\",\"import\":\"import\",\"list\":\"list\",\"print\":\"print\",\"search\":\"search\",\"view\":\"view\"}" );
$tdataaplikasisurvey[".originalDefaultPages"] = $tdataaplikasisurvey[".defaultPages"];

//	field labels
$fieldLabelsaplikasisurvey = array();
$fieldToolTipsaplikasisurvey = array();
$pageTitlesaplikasisurvey = array();
$placeHoldersaplikasisurvey = array();

if(mlang_getcurrentlang()=="English")
{
	$fieldLabelsaplikasisurvey["English"] = array();
	$fieldToolTipsaplikasisurvey["English"] = array();
	$placeHoldersaplikasisurvey["English"] = array();
	$pageTitlesaplikasisurvey["English"] = array();
	$fieldLabelsaplikasisurvey["English"]["id"] = "Id";
	$fieldToolTipsaplikasisurvey["English"]["id"] = "";
	$placeHoldersaplikasisurvey["English"]["id"] = "";
	$fieldLabelsaplikasisurvey["English"]["Nama_Inisal"] = "Nama/Inisal";
	$fieldToolTipsaplikasisurvey["English"]["Nama_Inisal"] = "";
	$placeHoldersaplikasisurvey["English"]["Nama_Inisal"] = "";
	$fieldLabelsaplikasisurvey["English"]["Umur"] = "Umur";
	$fieldToolTipsaplikasisurvey["English"]["Umur"] = "";
	$placeHoldersaplikasisurvey["English"]["Umur"] = "";
	$fieldLabelsaplikasisurvey["English"]["Tanggal_Kunjungan"] = "Tanggal Kunjungan";
	$fieldToolTipsaplikasisurvey["English"]["Tanggal_Kunjungan"] = "";
	$placeHoldersaplikasisurvey["English"]["Tanggal_Kunjungan"] = "";
	$fieldLabelsaplikasisurvey["English"]["Waktu_Kunjungan"] = "Waktu Kunjungan";
	$fieldToolTipsaplikasisurvey["English"]["Waktu_Kunjungan"] = "";
	$placeHoldersaplikasisurvey["English"]["Waktu_Kunjungan"] = "";
	$fieldLabelsaplikasisurvey["English"]["Poli"] = "Poli";
	$fieldToolTipsaplikasisurvey["English"]["Poli"] = "";
	$placeHoldersaplikasisurvey["English"]["Poli"] = "";
	$fieldLabelsaplikasisurvey["English"]["Kritik"] = "Kritik";
	$fieldToolTipsaplikasisurvey["English"]["Kritik"] = "";
	$placeHoldersaplikasisurvey["English"]["Kritik"] = "";
	$fieldLabelsaplikasisurvey["English"]["Saran"] = "Saran";
	$fieldToolTipsaplikasisurvey["English"]["Saran"] = "";
	$placeHoldersaplikasisurvey["English"]["Saran"] = "";
	$fieldLabelsaplikasisurvey["English"]["Foto"] = "Foto";
	$fieldToolTipsaplikasisurvey["English"]["Foto"] = "";
	$placeHoldersaplikasisurvey["English"]["Foto"] = "";
	if (count($fieldToolTipsaplikasisurvey["English"]))
		$tdataaplikasisurvey[".isUseToolTips"] = true;
}


	$tdataaplikasisurvey[".NCSearch"] = true;



$tdataaplikasisurvey[".shortTableName"] = "aplikasisurvey";
$tdataaplikasisurvey[".nSecOptions"] = 0;

$tdataaplikasisurvey[".mainTableOwnerID"] = "";
$tdataaplikasisurvey[".entityType"] = 0;
$tdataaplikasisurvey[".connId"] = "dataAplikasiSurveyatlocalhost";


$tdataaplikasisurvey[".strOriginalTableName"] = "aplikasisurvey";

	



$tdataaplikasisurvey[".showAddInPopup"] = false;

$tdataaplikasisurvey[".showEditInPopup"] = false;

$tdataaplikasisurvey[".showViewInPopup"] = false;

$tdataaplikasisurvey[".listAjax"] = false;
//	temporary
//$tdataaplikasisurvey[".listAjax"] = false;

	$tdataaplikasisurvey[".audit"] = false;

	$tdataaplikasisurvey[".locking"] = false;


$pages = $tdataaplikasisurvey[".defaultPages"];

if( $pages[PAGE_EDIT] ) {
	$tdataaplikasisurvey[".edit"] = true;
	$tdataaplikasisurvey[".afterEditAction"] = 1;
	$tdataaplikasisurvey[".closePopupAfterEdit"] = 1;
	$tdataaplikasisurvey[".afterEditActionDetTable"] = "";
}

if( $pages[PAGE_ADD] ) {
$tdataaplikasisurvey[".add"] = true;
$tdataaplikasisurvey[".afterAddAction"] = 1;
$tdataaplikasisurvey[".closePopupAfterAdd"] = 1;
$tdataaplikasisurvey[".afterAddActionDetTable"] = "";
}

if( $pages[PAGE_LIST] ) {
	$tdataaplikasisurvey[".list"] = true;
}



$tdataaplikasisurvey[".strSortControlSettingsJSON"] = "";




if( $pages[PAGE_VIEW] ) {
$tdataaplikasisurvey[".view"] = true;
}

if( $pages[PAGE_IMPORT] ) {
$tdataaplikasisurvey[".import"] = true;
}

if( $pages[PAGE_EXPORT] ) {
$tdataaplikasisurvey[".exportTo"] = true;
}

if( $pages[PAGE_PRINT] ) {
$tdataaplikasisurvey[".printFriendly"] = true;
}



$tdataaplikasisurvey[".showSimpleSearchOptions"] = true; // temp fix #13449

// Allow Show/Hide Fields in GRID
$tdataaplikasisurvey[".allowShowHideFields"] = true; // temp fix #13449
//

// Allow Fields Reordering in GRID
$tdataaplikasisurvey[".allowFieldsReordering"] = true; // temp fix #13449
//

$tdataaplikasisurvey[".isUseAjaxSuggest"] = true;





$tdataaplikasisurvey[".ajaxCodeSnippetAdded"] = false;

$tdataaplikasisurvey[".buttonsAdded"] = false;

$tdataaplikasisurvey[".addPageEvents"] = false;

// use timepicker for search panel
$tdataaplikasisurvey[".isUseTimeForSearch"] = false;


$tdataaplikasisurvey[".badgeColor"] = "CD853F";


$tdataaplikasisurvey[".allSearchFields"] = array();
$tdataaplikasisurvey[".filterFields"] = array();
$tdataaplikasisurvey[".requiredSearchFields"] = array();

$tdataaplikasisurvey[".googleLikeFields"] = array();
$tdataaplikasisurvey[".googleLikeFields"][] = "id";
$tdataaplikasisurvey[".googleLikeFields"][] = "Nama/Inisal";
$tdataaplikasisurvey[".googleLikeFields"][] = "Umur";
$tdataaplikasisurvey[".googleLikeFields"][] = "Tanggal Kunjungan";
$tdataaplikasisurvey[".googleLikeFields"][] = "Waktu Kunjungan";
$tdataaplikasisurvey[".googleLikeFields"][] = "Poli";
$tdataaplikasisurvey[".googleLikeFields"][] = "Kritik";
$tdataaplikasisurvey[".googleLikeFields"][] = "Saran";
$tdataaplikasisurvey[".googleLikeFields"][] = "Foto";



$tdataaplikasisurvey[".tableType"] = "list";

$tdataaplikasisurvey[".printerPageOrientation"] = 0;
$tdataaplikasisurvey[".nPrinterPageScale"] = 100;

$tdataaplikasisurvey[".nPrinterSplitRecords"] = 40;

$tdataaplikasisurvey[".geocodingEnabled"] = false;










$tdataaplikasisurvey[".pageSize"] = 20;

$tdataaplikasisurvey[".warnLeavingPages"] = true;



$tstrOrderBy = "";
$tdataaplikasisurvey[".strOrderBy"] = $tstrOrderBy;

$tdataaplikasisurvey[".orderindexes"] = array();


$tdataaplikasisurvey[".sqlHead"] = "SELECT id,  	`Nama/Inisal`,  	Umur,  	`Tanggal Kunjungan`,  	`Waktu Kunjungan`,  	Poli,  	Kritik,  	Saran,  	Foto";
$tdataaplikasisurvey[".sqlFrom"] = "FROM AplikasiSurvey";
$tdataaplikasisurvey[".sqlWhereExpr"] = "";
$tdataaplikasisurvey[".sqlTail"] = "";










//fill array of records per page for list and report without group fields
$arrRPP = array();
$arrRPP[] = 10;
$arrRPP[] = 20;
$arrRPP[] = 30;
$arrRPP[] = 50;
$arrRPP[] = 100;
$arrRPP[] = 500;
$arrRPP[] = -1;
$tdataaplikasisurvey[".arrRecsPerPage"] = $arrRPP;

//fill array of groups per page for report with group fields
$arrGPP = array();
$arrGPP[] = 1;
$arrGPP[] = 3;
$arrGPP[] = 5;
$arrGPP[] = 10;
$arrGPP[] = 50;
$arrGPP[] = 100;
$arrGPP[] = -1;
$tdataaplikasisurvey[".arrGroupsPerPage"] = $arrGPP;

$tdataaplikasisurvey[".highlightSearchResults"] = true;

$tableKeysaplikasisurvey = array();
$tableKeysaplikasisurvey[] = "id";
$tdataaplikasisurvey[".Keys"] = $tableKeysaplikasisurvey;


$tdataaplikasisurvey[".hideMobileList"] = array();




//	id
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 1;
	$fdata["strName"] = "id";
	$fdata["GoodName"] = "id";
	$fdata["ownerTable"] = "aplikasisurvey";
	$fdata["Label"] = GetFieldLabel("aplikasisurvey","id");
	$fdata["FieldType"] = 3;


		$fdata["AutoInc"] = true;

	
			

		$fdata["strField"] = "id";

		$fdata["sourceSingle"] = "id";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "id";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



		$edata["IsRequired"] = true;

	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
				$edata["validateAs"]["basicValidate"][] = getJsValidatorName("Number");
						$edata["validateAs"]["basicValidate"][] = "IsRequired";
		
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataaplikasisurvey["id"] = $fdata;
		$tdataaplikasisurvey[".searchableFields"][] = "id";
//	Nama/Inisal
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 2;
	$fdata["strName"] = "Nama/Inisal";
	$fdata["GoodName"] = "Nama_Inisal";
	$fdata["ownerTable"] = "aplikasisurvey";
	$fdata["Label"] = GetFieldLabel("aplikasisurvey","Nama_Inisal");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Nama/Inisal";

		$fdata["sourceSingle"] = "Nama/Inisal";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Nama/Inisal`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataaplikasisurvey["Nama/Inisal"] = $fdata;
		$tdataaplikasisurvey[".searchableFields"][] = "Nama/Inisal";
//	Umur
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 3;
	$fdata["strName"] = "Umur";
	$fdata["GoodName"] = "Umur";
	$fdata["ownerTable"] = "aplikasisurvey";
	$fdata["Label"] = GetFieldLabel("aplikasisurvey","Umur");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Umur";

		$fdata["sourceSingle"] = "Umur";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Umur";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataaplikasisurvey["Umur"] = $fdata;
		$tdataaplikasisurvey[".searchableFields"][] = "Umur";
//	Tanggal Kunjungan
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 4;
	$fdata["strName"] = "Tanggal Kunjungan";
	$fdata["GoodName"] = "Tanggal_Kunjungan";
	$fdata["ownerTable"] = "aplikasisurvey";
	$fdata["Label"] = GetFieldLabel("aplikasisurvey","Tanggal_Kunjungan");
	$fdata["FieldType"] = 7;


	
	
			

		$fdata["strField"] = "Tanggal Kunjungan";

		$fdata["sourceSingle"] = "Tanggal Kunjungan";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Tanggal Kunjungan`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Short Date");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Date");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
		$edata["DateEditType"] = 13;
	$edata["InitialYearFactor"] = 100;
	$edata["LastYearFactor"] = 10;

	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataaplikasisurvey["Tanggal Kunjungan"] = $fdata;
		$tdataaplikasisurvey[".searchableFields"][] = "Tanggal Kunjungan";
//	Waktu Kunjungan
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 5;
	$fdata["strName"] = "Waktu Kunjungan";
	$fdata["GoodName"] = "Waktu_Kunjungan";
	$fdata["ownerTable"] = "aplikasisurvey";
	$fdata["Label"] = GetFieldLabel("aplikasisurvey","Waktu_Kunjungan");
	$fdata["FieldType"] = 134;


	
	
			

		$fdata["strField"] = "Waktu Kunjungan";

		$fdata["sourceSingle"] = "Waktu Kunjungan";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "`Waktu Kunjungan`";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Time");

	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["timeFormatData"] = array(
		"showSeconds" => false,
		"showDaysInTotals" => false,
		"timeFormat" => 0
	);
	$vdata["timeFormatData"]["showSeconds"] = true;
	$vdata["timeFormatData"]["showDaysInTotals"] = true;

		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Time");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
		$edata["EditParams"] = "";
		
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
				$hours = 24;
	$edata["FormatTimeAttrs"] = array("useTimePicker" => 0,
									  "hours" => $hours,
									  "minutes" => 1,
									  "showSeconds" => 0);

	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Equals";

			// the default search options list
				$fdata["searchOptionsList"] = array("Equals", "More than", "Less than", "Between", EMPTY_SEARCH, NOT_EMPTY );
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataaplikasisurvey["Waktu Kunjungan"] = $fdata;
		$tdataaplikasisurvey[".searchableFields"][] = "Waktu Kunjungan";
//	Poli
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 6;
	$fdata["strName"] = "Poli";
	$fdata["GoodName"] = "Poli";
	$fdata["ownerTable"] = "aplikasisurvey";
	$fdata["Label"] = GetFieldLabel("aplikasisurvey","Poli");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Poli";

		$fdata["sourceSingle"] = "Poli";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Poli";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=50";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataaplikasisurvey["Poli"] = $fdata;
		$tdataaplikasisurvey[".searchableFields"][] = "Poli";
//	Kritik
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 7;
	$fdata["strName"] = "Kritik";
	$fdata["GoodName"] = "Kritik";
	$fdata["ownerTable"] = "aplikasisurvey";
	$fdata["Label"] = GetFieldLabel("aplikasisurvey","Kritik");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Kritik";

		$fdata["sourceSingle"] = "Kritik";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Kritik";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=500";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataaplikasisurvey["Kritik"] = $fdata;
		$tdataaplikasisurvey[".searchableFields"][] = "Kritik";
//	Saran
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 8;
	$fdata["strName"] = "Saran";
	$fdata["GoodName"] = "Saran";
	$fdata["ownerTable"] = "aplikasisurvey";
	$fdata["Label"] = GetFieldLabel("aplikasisurvey","Saran");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Saran";

		$fdata["sourceSingle"] = "Saran";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Saran";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "");

	
	
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["NeedEncode"] = true;

	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Text field");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
			$edata["HTML5InuptType"] = "text";

		$edata["EditParams"] = "";
			$edata["EditParams"].= " maxlength=500";

		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataaplikasisurvey["Saran"] = $fdata;
		$tdataaplikasisurvey[".searchableFields"][] = "Saran";
//	Foto
//	Custom field settings
	$fdata = array();
	$fdata["Index"] = 9;
	$fdata["strName"] = "Foto";
	$fdata["GoodName"] = "Foto";
	$fdata["ownerTable"] = "aplikasisurvey";
	$fdata["Label"] = GetFieldLabel("aplikasisurvey","Foto");
	$fdata["FieldType"] = 200;


	
	
			

		$fdata["strField"] = "Foto";

		$fdata["sourceSingle"] = "Foto";

	
		$fdata["isSQLExpression"] = true;
	$fdata["FullName"] = "Foto";

	
	
				$fdata["UploadFolder"] = "files";

//  Begin View Formats
	$fdata["ViewFormats"] = array();

	$vdata = array("ViewFormat" => "Document Download");

	
	
	
								$vdata["ShowIcon"] = true;
				
	
	
	
	
	
	
	
	
	
	
	
	
		$vdata["truncateText"] = true;
	$vdata["NumberOfChars"] = 80;

	$fdata["ViewFormats"]["view"] = $vdata;
//  End View Formats

//	Begin Edit Formats
	$fdata["EditFormats"] = array();

	$edata = array("EditFormat" => "Document upload");

	
		$edata["weekdayMessage"] = array("message" => "", "messageType" => "Text");
	$edata["weekdays"] = "[]";


	
	



	
	
	
	
			$edata["acceptFileTypesHtml"] = "";

		$edata["maxNumberOfFiles"] = 1;

	
	
	
	
	
	
		$edata["controlWidth"] = 200;

//	Begin validation
	$edata["validateAs"] = array();
	$edata["validateAs"]["basicValidate"] = array();
	$edata["validateAs"]["customMessages"] = array();
	
	
//	End validation

	
			
	
	
	
	$fdata["EditFormats"]["edit"] = $edata;
//	End Edit Formats


	$fdata["isSeparate"] = false;




// the field's search options settings
		$fdata["defaultSearchOption"] = "Contains";

			// the default search options list
				$fdata["searchOptionsList"] = array("Contains", "Equals", "Starts with", "More than", "Less than", "Between", "Empty", NOT_EMPTY);
// the end of search options settings


//Filters settings
	$fdata["filterTotals"] = 0;
		$fdata["filterMultiSelect"] = 0;
			$fdata["filterFormat"] = "Values list";
		$fdata["showCollapsed"] = false;

		$fdata["sortValueType"] = 0;
		$fdata["numberOfVisibleItems"] = 10;

		$fdata["filterBy"] = 0;

	

	
	
//end of Filters settings


	$tdataaplikasisurvey["Foto"] = $fdata;
		$tdataaplikasisurvey[".searchableFields"][] = "Foto";


$tables_data["aplikasisurvey"]=&$tdataaplikasisurvey;
$field_labels["aplikasisurvey"] = &$fieldLabelsaplikasisurvey;
$fieldToolTips["aplikasisurvey"] = &$fieldToolTipsaplikasisurvey;
$placeHolders["aplikasisurvey"] = &$placeHoldersaplikasisurvey;
$page_titles["aplikasisurvey"] = &$pageTitlesaplikasisurvey;


changeTextControlsToDate( "aplikasisurvey" );

// -----------------start  prepare master-details data arrays ------------------------------//
// tables which are detail tables for current table (master)

//if !@TABLE.bReportCrossTab

$detailsTablesData["aplikasisurvey"] = array();
//endif

// tables which are master tables for current table (detail)
$masterTablesData["aplikasisurvey"] = array();



// -----------------end  prepare master-details data arrays ------------------------------//



require_once(getabspath("classes/sql.php"));











function createSqlQuery_aplikasisurvey()
{
$proto0=array();
$proto0["m_strHead"] = "SELECT";
$proto0["m_strFieldList"] = "id,  	`Nama/Inisal`,  	Umur,  	`Tanggal Kunjungan`,  	`Waktu Kunjungan`,  	Poli,  	Kritik,  	Saran,  	Foto";
$proto0["m_strFrom"] = "FROM AplikasiSurvey";
$proto0["m_strWhere"] = "";
$proto0["m_strOrderBy"] = "";
	
		;
			$proto0["cipherer"] = null;
$proto2=array();
$proto2["m_sql"] = "";
$proto2["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto2["m_column"]=$obj;
$proto2["m_contained"] = array();
$proto2["m_strCase"] = "";
$proto2["m_havingmode"] = false;
$proto2["m_inBrackets"] = false;
$proto2["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto2);

$proto0["m_where"] = $obj;
$proto4=array();
$proto4["m_sql"] = "";
$proto4["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto4["m_column"]=$obj;
$proto4["m_contained"] = array();
$proto4["m_strCase"] = "";
$proto4["m_havingmode"] = false;
$proto4["m_inBrackets"] = false;
$proto4["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto4);

$proto0["m_having"] = $obj;
$proto0["m_fieldlist"] = array();
						$proto6=array();
			$obj = new SQLField(array(
	"m_strName" => "id",
	"m_strTable" => "aplikasisurvey",
	"m_srcTableName" => "aplikasisurvey"
));

$proto6["m_sql"] = "id";
$proto6["m_srcTableName"] = "aplikasisurvey";
$proto6["m_expr"]=$obj;
$proto6["m_alias"] = "";
$obj = new SQLFieldListItem($proto6);

$proto0["m_fieldlist"][]=$obj;
						$proto8=array();
			$obj = new SQLField(array(
	"m_strName" => "Nama/Inisal",
	"m_strTable" => "aplikasisurvey",
	"m_srcTableName" => "aplikasisurvey"
));

$proto8["m_sql"] = "`Nama/Inisal`";
$proto8["m_srcTableName"] = "aplikasisurvey";
$proto8["m_expr"]=$obj;
$proto8["m_alias"] = "";
$obj = new SQLFieldListItem($proto8);

$proto0["m_fieldlist"][]=$obj;
						$proto10=array();
			$obj = new SQLField(array(
	"m_strName" => "Umur",
	"m_strTable" => "aplikasisurvey",
	"m_srcTableName" => "aplikasisurvey"
));

$proto10["m_sql"] = "Umur";
$proto10["m_srcTableName"] = "aplikasisurvey";
$proto10["m_expr"]=$obj;
$proto10["m_alias"] = "";
$obj = new SQLFieldListItem($proto10);

$proto0["m_fieldlist"][]=$obj;
						$proto12=array();
			$obj = new SQLField(array(
	"m_strName" => "Tanggal Kunjungan",
	"m_strTable" => "aplikasisurvey",
	"m_srcTableName" => "aplikasisurvey"
));

$proto12["m_sql"] = "`Tanggal Kunjungan`";
$proto12["m_srcTableName"] = "aplikasisurvey";
$proto12["m_expr"]=$obj;
$proto12["m_alias"] = "";
$obj = new SQLFieldListItem($proto12);

$proto0["m_fieldlist"][]=$obj;
						$proto14=array();
			$obj = new SQLField(array(
	"m_strName" => "Waktu Kunjungan",
	"m_strTable" => "aplikasisurvey",
	"m_srcTableName" => "aplikasisurvey"
));

$proto14["m_sql"] = "`Waktu Kunjungan`";
$proto14["m_srcTableName"] = "aplikasisurvey";
$proto14["m_expr"]=$obj;
$proto14["m_alias"] = "";
$obj = new SQLFieldListItem($proto14);

$proto0["m_fieldlist"][]=$obj;
						$proto16=array();
			$obj = new SQLField(array(
	"m_strName" => "Poli",
	"m_strTable" => "aplikasisurvey",
	"m_srcTableName" => "aplikasisurvey"
));

$proto16["m_sql"] = "Poli";
$proto16["m_srcTableName"] = "aplikasisurvey";
$proto16["m_expr"]=$obj;
$proto16["m_alias"] = "";
$obj = new SQLFieldListItem($proto16);

$proto0["m_fieldlist"][]=$obj;
						$proto18=array();
			$obj = new SQLField(array(
	"m_strName" => "Kritik",
	"m_strTable" => "aplikasisurvey",
	"m_srcTableName" => "aplikasisurvey"
));

$proto18["m_sql"] = "Kritik";
$proto18["m_srcTableName"] = "aplikasisurvey";
$proto18["m_expr"]=$obj;
$proto18["m_alias"] = "";
$obj = new SQLFieldListItem($proto18);

$proto0["m_fieldlist"][]=$obj;
						$proto20=array();
			$obj = new SQLField(array(
	"m_strName" => "Saran",
	"m_strTable" => "aplikasisurvey",
	"m_srcTableName" => "aplikasisurvey"
));

$proto20["m_sql"] = "Saran";
$proto20["m_srcTableName"] = "aplikasisurvey";
$proto20["m_expr"]=$obj;
$proto20["m_alias"] = "";
$obj = new SQLFieldListItem($proto20);

$proto0["m_fieldlist"][]=$obj;
						$proto22=array();
			$obj = new SQLField(array(
	"m_strName" => "Foto",
	"m_strTable" => "aplikasisurvey",
	"m_srcTableName" => "aplikasisurvey"
));

$proto22["m_sql"] = "Foto";
$proto22["m_srcTableName"] = "aplikasisurvey";
$proto22["m_expr"]=$obj;
$proto22["m_alias"] = "";
$obj = new SQLFieldListItem($proto22);

$proto0["m_fieldlist"][]=$obj;
$proto0["m_fromlist"] = array();
												$proto24=array();
$proto24["m_link"] = "SQLL_MAIN";
			$proto25=array();
$proto25["m_strName"] = "aplikasisurvey";
$proto25["m_srcTableName"] = "aplikasisurvey";
$proto25["m_columns"] = array();
$proto25["m_columns"][] = "id";
$proto25["m_columns"][] = "Nama/Inisal";
$proto25["m_columns"][] = "Umur";
$proto25["m_columns"][] = "Tanggal Kunjungan";
$proto25["m_columns"][] = "Waktu Kunjungan";
$proto25["m_columns"][] = "Poli";
$proto25["m_columns"][] = "Kritik";
$proto25["m_columns"][] = "Saran";
$proto25["m_columns"][] = "Foto";
$obj = new SQLTable($proto25);

$proto24["m_table"] = $obj;
$proto24["m_sql"] = "AplikasiSurvey";
$proto24["m_alias"] = "";
$proto24["m_srcTableName"] = "aplikasisurvey";
$proto26=array();
$proto26["m_sql"] = "";
$proto26["m_uniontype"] = "SQLL_UNKNOWN";
	$obj = new SQLNonParsed(array(
	"m_sql" => ""
));

$proto26["m_column"]=$obj;
$proto26["m_contained"] = array();
$proto26["m_strCase"] = "";
$proto26["m_havingmode"] = false;
$proto26["m_inBrackets"] = false;
$proto26["m_useAlias"] = false;
$obj = new SQLLogicalExpr($proto26);

$proto24["m_joinon"] = $obj;
$obj = new SQLFromListItem($proto24);

$proto0["m_fromlist"][]=$obj;
$proto0["m_groupby"] = array();
$proto0["m_orderby"] = array();
$proto0["m_srcTableName"]="aplikasisurvey";		
$obj = new SQLQuery($proto0);

	return $obj;
}
$queryData_aplikasisurvey = createSqlQuery_aplikasisurvey();


	
		;

									

$tdataaplikasisurvey[".sqlquery"] = $queryData_aplikasisurvey;



$tdataaplikasisurvey[".hasEvents"] = false;

?>