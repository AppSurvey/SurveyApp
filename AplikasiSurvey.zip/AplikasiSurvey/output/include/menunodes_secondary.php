<?php

	// create menu nodes arr
	$menuNodes = array();

	$menuNodesCache[ "secondary" ] = $menuNodes;
?>